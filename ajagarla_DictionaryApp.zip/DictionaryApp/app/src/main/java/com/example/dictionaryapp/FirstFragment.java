// Name: Akhila Jagarlapudi
// Andrew ID: ajagarla

// This fragment handles the main dictionary lookup screen in the Android app.
// It lets users enter a word, search for the meaning using the web service, and shows the result.
// The UI includes a header image, a search box, a search button, and an output area.
// All logic to call the API and show the results is handled here.
// Used LLMs such as ChatGPT and Claude.AI to help me with this code.


package com.example.dictionaryapp;

import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.text.HtmlCompat;
import androidx.fragment.app.Fragment;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FirstFragment extends Fragment {

    private EditText inputWord;
    private TextView resultView;
    private Button searchButton;
    private ImageView headerImage;

    private Button clearButton;

    // Localhost for emulator; replaced with cloud URL
    // private final String API_URL = "http://10.0.2.2:8080/Project4_war_exploded/lookup?word=";
    private final String API_URL = "https://laughing-halibut-5rgx6vvx9r434vx6-8080.app.github.dev/lookup?word=";

    // Inflate the layout and wire up all UI elements
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        inputWord = view.findViewById(R.id.inputWord); // user input box
        resultView = view.findViewById(R.id.resultView); // area where results are shown
        searchButton = view.findViewById(R.id.searchBtn); // triggers the API call
        headerImage = view.findViewById(R.id.headerImage); // image on top of the screen

        // Font styling (Times New Roman is not guaranteed on all Android devices)
        inputWord.setTypeface(Typeface.SERIF);
        resultView.setTypeface(Typeface.SERIF);
        searchButton.setTypeface(Typeface.SERIF);

        // When search is clicked, start async lookup
        searchButton.setOnClickListener(v -> {
            String word = inputWord.getText().toString().trim();
            if (!word.isEmpty()) {
                new LookupTask().execute(word);
            } else {
                resultView.setText("Please enter a word.");
            }
        });

        return view;

    }

    // AsyncTask so the network call doesn't block the UI
    private class LookupTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String endpoint = API_URL + params[0];
                HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Device-Model", "AndroidEmulator");

                // If 200, use input stream. If not, use error stream.
                int responseCode = connection.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        responseCode == 200 ? connection.getInputStream() : connection.getErrorStream()
                ));

                // Read the full response
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();

            } catch (Exception e) {
                return "Error: " + e.getMessage();  // fallback if something goes wrong
            }
        }

        @Override
        protected void onPostExecute(String result) {
            String definition;
            String formattedOutput;

            try {
                JSONObject json = new JSONObject(result);

                // Try to pull out the definition if it exists
                if (json.has("definition")) {
                    // Show actual definition from JSON
                    definition = json.getString("definition");
                } else {
                    // Something went wrong with parsing, show fallback message
                    definition = "Since this is a free API, only words starting with the letter 'A' work and give you definitions. Words you may try are: Ace, Apple, Arrow, etc.";
                }
            } catch (Exception e) {
                definition = "Since this is a free API, only words starting with the letter 'A' work and give you definitions. Words you may try are: Ace, Apple, Arrow, etc.";
            }

            // Build the final output message with formatting
            formattedOutput = "<b><u>Definition:</u></b><br/><i>\"" + definition + "\"</i>"
                    + "<br/><br/><b>Raw Message:</b><br/>" + result;

            resultView.setText(HtmlCompat.fromHtml(formattedOutput, HtmlCompat.FROM_HTML_MODE_LEGACY));
        }
    }
}

